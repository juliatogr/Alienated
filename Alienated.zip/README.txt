NOMBRE: Júlia Tortosa Grau
NIA: 227215
UNIS: u173375
EMAIL: julia.tortosa01@estudiant.upf.edu

Link al video de youtube: https://www.youtube.com/watch?v=PQFnSkHcn0M

COMENTARIOS:

- He incluido bastante botón para facilitar la interacción con el usuario. No habrá ningún botón seleccionado 
  a no ser que el usuario pulse las flechas UP o DOWN para indicar que quiere moverse por la pantalla.

	- NEW GAME empieza un juego nuevo
	- TUTORIAL lleva al tutorial del juego
	- EXIT cierra la aplicación

- El botón de MENU no se ve específicamente, pero se puede acceder a el apretando la letra X durante el tutorial o 
  el juego. Tiene botones para
	- volver a la introducción (INTRO)
	- volver atrás (RESUME) y EXIT.
	- si el menú es del tutorial, también permite empezar juego nuevo
	- si el menú es del juego, también permite ir al tutorial.

- He implementado la usabilidad con gamepad pero va rara. Según he testeado, el stick no va bien para moverse por los botones,
  es muy sensible y se mueve muy rápido.

- El stage de END cambia según si el jugador ha ganado (se ven corazones y robots) o ha perdido (se ven aliens).

- Me parecía interesante crear un background con efecto parallax y ahí está, espero que se pueda apreciar!

- Me hubiera gustado hacer que los jefes finales dispararan (por eso que se puede agachar el robot, para esquivar sus balas),
  y que los ovnis lo hicieran también, pero de arriba a abajo. Sin embargo, no me dio tiempo de hacer más.

- Tuve un error al pasarlo a modo debug, pero lo arreglé a la mañana siguiente, por eso he actualizado la entrega.